﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    internal class Calculate
    {
        
        public void sum(int a, int b)
        {
            Console.WriteLine("Sum = ", a + b);
        }

        public void subtract(int a, int b)
        {
            Console.WriteLine("Substract ", a - b);
        }

    }
}
